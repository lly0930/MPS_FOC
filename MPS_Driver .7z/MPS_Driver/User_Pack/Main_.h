//
// Created by 29787 on 2024/4/20.
//

#ifndef PROJECT_MAIN__H
#define PROJECT_MAIN__H

_Noreturn void Main();
void Pack(uint8_t *buf);
#endif //PROJECT_MAIN__H
